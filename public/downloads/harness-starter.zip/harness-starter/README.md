# HARNESS sample revenue bug

Synthetic data only. Needs Node.js 20+ and Python 3 for the optional browser view.

1. Run `node --test revenue.test.mjs`: the initial project has the bug.
2. Run `python3 -m http.server 8000`, then open http://localhost:8000.
3. Ask your coding agent to reproduce, explain and fix the bug.
4. Expected revenue is 143000 cents ($1,430.00), counting only paid invoices.
5. Run all four tests and refresh the browser. Review the diff.

The reference fix is available as a spoiler on the HARNESS checklist page. The focused skill template is in skill/SKILL.md; install it in the location your chosen agent supports.

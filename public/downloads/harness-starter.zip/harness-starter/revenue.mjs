export function paidRevenue(invoices) {
  return invoices.filter(invoice => invoice.status !== 'cancelled')
    .reduce((total, invoice) => total + invoice.amountCents, 0);
}

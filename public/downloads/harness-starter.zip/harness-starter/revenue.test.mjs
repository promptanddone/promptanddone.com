import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {paidRevenue} from './revenue.mjs';
const invoices = JSON.parse(readFileSync(new URL('./invoices.json', import.meta.url)));
test('paid revenue excludes refunded invoices', () => assert.equal(paidRevenue(invoices), 143000));
test('empty ledger has zero revenue', () => assert.equal(paidRevenue([]), 0));
test('pending and cancelled invoices are not revenue', () => assert.equal(paidRevenue([{amountCents:9000,status:'pending'},{amountCents:6000,status:'cancelled'}]), 0));
test('cents are preserved exactly', () => assert.equal(paidRevenue([{amountCents:101,status:'paid'},{amountCents:202,status:'paid'}]), 303));

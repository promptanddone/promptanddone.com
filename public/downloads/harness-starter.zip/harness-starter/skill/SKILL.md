---
name: reproduce-and-fix
description: Reproduce a reported bug, identify its cause, and verify a small fix.
---

1. Read the report and relevant project instructions.
2. Reproduce the behavior with existing tests or a concrete input.
3. Explain the cause using the code and observed output.
4. Make the smallest change that solves the reported behavior.
5. Run relevant checks and inspect the actual result.
6. Report the change, evidence, and any remaining uncertainty.
